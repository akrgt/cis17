from otree.api import (
    models,
    widgets,
    BaseConstants,
    BaseSubsession,
    BaseGroup,
    BasePlayer,
    Currency as c,
    currency_range,
)

from django import forms

author = 'Your name here'

doc = """
Your app description
"""


class Constants(BaseConstants):
    name_in_url = 'imc'
    players_per_group = None
    num_rounds = 1


class Subsession(BaseSubsession):
    introjs = models.IntegerField()

    def get_game(self):
        self.introjs = self.session.config['introjs']



class Group(BaseGroup):
    pass


class Player(BasePlayer):
    imc1_1 = models.BooleanField(initial=None,
                               label='強くそう思う',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc1_2 = models.BooleanField(initial=None,
                               label='そう思う',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc1_3 = models.BooleanField(initial=None,
                               label='どちらとも言えない',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc1_4 = models.BooleanField(initial=None,
                               label='そう思わない',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc1_5 = models.BooleanField(initial=None,
                               label='全くそう思わない',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc2_1 = models.BooleanField(initial=None,
                               label='強くそう思う',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc2_2 = models.BooleanField(initial=None,
                               label='そう思う',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc2_3 = models.BooleanField(initial=None,
                               label='どちらとも言えない',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc2_4 = models.BooleanField(initial=None,
                               label='そう思わない',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc2_5 = models.BooleanField(initial=None,
                               label='全くそう思わない',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc3_1 = models.BooleanField(initial=None,
                               label='強くそう思う',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc3_2 = models.BooleanField(initial=None,
                               label='そう思う',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc3_3 = models.BooleanField(initial=None,
                               label='どちらとも言えない',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc3_4 = models.BooleanField(initial=None,
                               label='そう思わない',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
    imc3_5 = models.BooleanField(initial=None,
                               label='全くそう思わない',
                               widget=forms.CheckboxInput(attrs={'class': 'check'}
                               )
                             )
