from . import models
from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants


class game(Page):
    timeout_seconds = 0.1
    def vars_for_template(self):
        self.subsession.get_game()
    pass


class MyPage(Page):
    form_model = models.Player
    form_fields = ['imc1_1','imc1_2','imc1_3','imc1_4','imc1_5',
                    'imc2_1','imc2_2','imc2_3','imc2_4','imc2_5',
                    'imc3_1','imc3_2','imc3_3','imc3_4','imc3_5'
                    ]



page_sequence = [game,MyPage]
