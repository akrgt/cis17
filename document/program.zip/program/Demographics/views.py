from . import models
from ._builtin import Page, WaitPage
from otree.api import Currency as c, currency_range
from .models import Constants




class Demographics(Page):

    form_model = models.Player
    form_fields = ['q_tanmatsu',
                  'q_gender',
                  'q_age',
                  'q_country',
                  'q_aca',
                  'q_INK',
                  'q_INS',
                  'q_MAR',
                  'q_CHI']



    def before_next_page(self):
        self.player.set_payoff()

page_sequence = [
    Demographics,
]
