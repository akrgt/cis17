from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)
import random
from django import forms



class Constants(BaseConstants):
    name_in_url = 'Demographics'
    players_per_group = None
    num_rounds = 1


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    def set_payoff(self):
        """Calculate payoff, which is zero for the survey"""
        self.payoff = 0




    q_gender = models.CharField(initial=None,
                                choices=['男性', '女性', '回答しない'],
                                verbose_name='あなたの性別を教えてください．',
                                widget=forms.Select())
    q_age = models.PositiveIntegerField(verbose_name='あなたの年齢を教えてください．',
                                        choices=range(0, 125),
                                        initial=None)
    q_country = models.CharField(initial=None,
                                choices=['北海道', '青森県', '岩手県', '宮城県', '秋田県', '山形県', '福島県','茨城県', '栃木県', '群馬県', '埼玉県', '千葉県', '東京都', '神奈川県','新潟県', '富山県', '石川県', '福井県', '山梨県', '長野県', '岐阜県', '静岡県', '愛知県', '三重県','滋賀県', '京都府', '大阪府', '兵庫県', '奈良県', '和歌山県','鳥取県', '島根県', '岡山県', '広島県', '山口県','徳島県', '香川県', '愛媛県', '高知県','福岡県', '佐賀県', '長崎県', '熊本県', '大分県', '宮崎県', '鹿児島県', '沖縄県'],
                                verbose_name='あなたのおすまいの地域を教えてください．',
                                widget=forms.Select())

    q_tanmatsu = models.CharField(initial=None,
                                choices=['パソコン',
                                        'タブレット',
                                        'スマートフォン',
                                        'それ以外'
                                        ],
                                verbose_name='この回答は、どの電子機器で回答していますか？',
                                widget=forms.Select())


    q_aca = models.CharField(initial=None,
                                choices=['中学校卒業','高校中退','高校卒業','専門学校（短期大学）中退','専門学校（短期大学）卒業','大学中退','大学卒業','大学院修士課程（博士前期課程）中退','大学院修士課程（博士前期課程）修了','大学院博士課程（博士後期課程）中退','大学院博士課程（博士後期課程）修了'],
                                verbose_name='あなたの最終学歴を教えてください．',
                                widget=forms.Select())

    q_INK = models.CharField(initial=None,
                                choices=['0円','1円〜200万円未満','200万円以上〜400万円未満','400万円以上〜600万円未満','600万円以上〜800万円未満','800万円以上〜1,000万円未満','1,000万円以上〜1,200万円未満','1,200万円以上〜1,500万円未満','1,500万円以上〜2,000万円未満','2,000万円以上','わからない'],
                                verbose_name='あなたの個人収入(額面)を教えてください．',
                                widget=forms.Select())
    q_INS = models.CharField(initial=None,
                                choices=['0円','1円〜200万円未満','200万円以上〜400万円未満','400万円以上〜600万円未満','600万円以上〜800万円未満','800万円以上〜1,000万円未満','1,000万円以上〜1,200万円未満','1,200万円以上〜1,500万円未満','1,500万円以上〜2,000万円未満','2,000万円以上','わからない'],
                                verbose_name='あなたの世帯収入(額面)を教えてください．',
                                widget=forms.Select())
    q_MAR = models.CharField(initial=None,
                                choices=['未婚', '既婚'],
                                verbose_name='あなたは結婚されていますか？それとも結婚されていませんか？',
                                widget=forms.Select())
    q_CHI = models.CharField(initial=None,
                                choices=['子どもなし', '子どもあり'],
                                verbose_name='あなたは子どもがいますか？いませんか？',
                                widget=forms.Select())
