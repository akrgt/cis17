from otree.api import Currency as c, currency_range
from . import views
from ._builtin import Bot
from .models import Constants
import random

class PlayerBot(Bot):

    def play_round(self):

        yield (views.Demographics, {
            'q_country': '東京',
            'q_age': 24,
            'q_aca': '大学卒業',
            'q_gender': 'Male',
            'q_INK': '0円',
            'q_INS': '0円',
            'q_MAR': '未婚',
            'q_CHI': '子どもあり',
            })
