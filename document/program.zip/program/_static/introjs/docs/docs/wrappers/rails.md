---
layout: doc
title: Rails
categories: wrappers
permalink: /wrappers/rails
---

If you are using the rails asset pipeline you can use the [introjs-rails](https://github.com/heelhook/intro.js-rails) gem.

*Do you know a project that we didn't mention here? Please update the documentation on Github or [email](mailto:support@introjs.com) us.*
