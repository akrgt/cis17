---
layout: doc
title: Wordpress
categories: wrappers
permalink: /wrappers/wordpress
---

You can use IntroJS inside your Wordpress, here is a good article by SitePoint: [http://www.sitepoint.com/creating-intro-js-powered-tours-wordpress/](http://www.sitepoint.com/creating-intro-js-powered-tours-wordpress/)

Here is a under construction plugin for Wordpress: [https://github.com/newoldmedia/intro.js-wordpress](https://github.com/newoldmedia/intro.js-wordpress)

*Do you know a project that we didn't mention here? Please update the documentation on Github or [email](mailto:support@introjs.com) us.*
